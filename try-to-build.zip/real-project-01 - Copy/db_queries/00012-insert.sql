INSERT INTO users (
    first_name,
    last_name,
    email,
    password
) VALUES (
    'Sakib',
    'Sarkar',
    'alvinsar01@gmail.com',
    '1234'
)