UPDATE users SET
    last_name = 'SAKIB',
    first_name = 'ALVIN'
WHERE id = 5;
