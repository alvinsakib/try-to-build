DELETE FROM users
WHERE id = 5;
