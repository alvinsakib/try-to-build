-- +migrate Down
DROP TABLE IF EXISTS users;