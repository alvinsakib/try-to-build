package main

import (
	"ecommerce/cmd"
)

func main() {
	cmd.Serve()
}